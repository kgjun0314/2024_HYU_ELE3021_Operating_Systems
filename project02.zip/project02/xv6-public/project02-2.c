#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
    int pid;
    int priority;
    int level;
    int result;
    int i, j, n = 5;
    int password = 2020031603; // setmonopoly 시스템 콜에 사용될 비밀번호

    for (j = 0; j < n; j++)
    {
        pid = fork();
        if (pid == 0)
        {
            priority = getpid() % 11;
            result = setpriority(getpid(), priority);

            if (result == 0)
            {
                printf(1, "setpriority success. PID: %d, Priority: %d\n", getpid(), priority);
            }
            else
            {
                printf(1, "setpriority failed. PID: %d\n", getpid());
            }

            for (i = 0; i < 100; i++)
            {
                pid = getpid();
                level = getlev();
                printf(1, "Process PID: %d, Queue Level: %d\n", pid, level);
                yield();
            }
            exit();
        }
        else
        {
            setmonopoly(getpid(), password);
            monopolize();
            for (i = 0; i < 100; i++)
            {
                printf(1, "Monopolizing Process Iteration: %d\n", i);
            }
        }
    }

    for (j = 0; j < n; j++)
    {
        wait();
    }

    exit();
}