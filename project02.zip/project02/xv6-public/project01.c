#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
    int studentId = 2020031603;
    printf(1, "My student id is %d\n", studentId); // 내 학번 출력
    printf(1, "My pid is %d\n", getpid());         // 현재 프로세스 id 출력
    printf(1, "My gpid is %d\n", getgpid());       // 조부모 프로세스 id 출력
    exit();
}
