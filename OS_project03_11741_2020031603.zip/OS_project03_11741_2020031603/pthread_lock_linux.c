#include <stdio.h>
#include <pthread.h>

int shared_resource = 0;

#define NUM_ITERS 10
#define NUM_THREADS 10

int choosing[NUM_THREADS];  // 스레드가 순번 선택 중인지 여부
int number[NUM_THREADS];    // 스레드가 cs로 들어가기 위한 순번

void lock(int);
void unlock(int);

void lock(int i)
{
    // i번째 스레드가 순번 선택 중
    choosing[i] = 1;

    // cs로 들어갈 순번을 받는다.
    int max_number = -1;
    for (int tid = 0; tid < NUM_THREADS; tid++) {
        max_number = (number[tid] > max_number) ? number[tid] : max_number;
    }
    number[i] = max_number + 1;

    // i번째 스레드 순번 선택 종료
    choosing[i] = 0;
    
    for (int j = 0; j < NUM_THREADS; j++) {
        // j번째 스레드가 순번 받을 때 까지 대기
        while (choosing[j]);
        // j번째 스레드의 순번이 존재한다는 가정 하에
        // 현재 스레드보다 순번이 빠르거나, 순번은 동일한데 j가 현재 스레드의 tid인 i보다 작다면 대기
        while ((number[j] != 0) && (number[j] < number[i] || (number[j] == number[i] && j < i)));
    }
}

void unlock(int i)
{
    number[i] = 0;  // cs 수행 끝, 순번 삭제
}

void* thread_func(void* arg) {
    int tid = *(int*)arg;
    
    lock(tid);
    
    // for(int i = 0; i < NUM_ITERS; i++)    shared_resource++;

    for(int i = 0; i < NUM_ITERS; i++) {
        printf("tid: %d shared: %d\n", tid, shared_resource++);
    }

    unlock(tid);
    
    pthread_exit(NULL);
}

int main() {
    int n = NUM_THREADS;
    for (int i = 0; i < n; i++) {
        choosing[i] = 0;
        number[i] = 0;
    }

    pthread_t threads[n];
    int tids[n];
    
    for (int i = 0; i < n; i++) {
        tids[i] = i;
        pthread_create(&threads[i], NULL, thread_func, &tids[i]);
    }
    
    for (int i = 0; i < n; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("shared: %d\n", shared_resource);
    
    return 0;
}