#include "types.h"
#include "stat.h"
#include "user.h"

void childProcess()
{
    int priority = getpid() % 11;
    int result = setpriority(getpid(), priority);

    if (result == 0)
    {
        printf(1, "setpriority success. PID: %d, Priority: %d\n", getpid(), priority);
    }
    else
    {
        printf(1, "setpriority failed. PID: %d\n", getpid());
    }
    sleep(5); // 충분한 대기 시간을 제공하여 부모 프로세스가 monopolize를 호출할 수 있도록 함

    for (int i = 0; i < 50; i++)
    {
        int pid = getpid();
        int level = getlev();
        printf(1, "Process PID: %d, Queue Level: %d\n", pid, level);
        yield();
    }
    exit();
}

int main(void)
{
    int pid1, pid2, pid3;

    // 첫 번째 자식 프로세스 생성
    pid1 = fork();
    if (pid1 == 0)
    {
        childProcess();
    }
    else if (pid1 < 0)
    {
        printf(1, "첫 번째 자식 프로세스 생성 실패\n");
        exit();
    }

    // 두 번째 자식 프로세스 생성
    pid2 = fork();
    if (pid2 == 0)
    {
        childProcess();
    }
    else if (pid2 < 0)
    {
        printf(1, "두 번째 자식 프로세스 생성 실패\n");
        exit();
    }

    // 세 번째 자식 프로세스 생성
    pid3 = fork();
    if (pid3 == 0)
    {
        childProcess();
    }
    else if (pid3 < 0)
    {
        printf(1, "세 번째 자식 프로세스 생성 실패\n");
        exit();
    }

    // 부모 프로세스에서 monopolize 호출
    // 이 호출은 두 자식 프로세스가 setmonopoly에 의해 MoQ에 등록된 후 실행됩니다.
    sleep(15); // 자식 프로세스들이 setmonopoly를 호출하고 준비될 시간을 보장하기 위해 대기

    // 두 자식 프로세스가 종료될 때까지 기다림
    wait();
    wait();
    wait();

    exit();
}