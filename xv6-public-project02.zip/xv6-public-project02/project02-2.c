#include "types.h"
#include "stat.h"
#include "user.h"

void childProcess()
{
    // MoQ에 들어가서 준비하는 경우
    setmonopoly(getpid(), 2020031603);
    sleep(5); // 충분한 대기 시간을 제공하여 부모 프로세스가 monopolize를 호출할 수 있도록 함

    // 이제, 실제 작업을 시작합니다.
    for (int i = 1; i <= 1000; i++)
    {
        int p = getpid();
        printf(1, "PID: %d, ticks: %d\n", p, getticks());
    }

    exit(); // 자식 프로세스 종료
}

int main(void)
{
    int pid1, pid2;

    // 첫 번째 자식 프로세스 생성
    pid1 = fork();
    if (pid1 == 0)
    {
        childProcess();
    }
    else if (pid1 < 0)
    {
        printf(1, "첫 번째 자식 프로세스 생성 실패\n");
        exit();
    }

    // 두 번째 자식 프로세스 생성
    pid2 = fork();
    if (pid2 == 0)
    {
        childProcess();
    }
    else if (pid2 < 0)
    {
        printf(1, "두 번째 자식 프로세스 생성 실패\n");
        exit();
    }

    // 부모 프로세스에서 monopolize 호출
    // 이 호출은 두 자식 프로세스가 setmonopoly에 의해 MoQ에 등록된 후 실행됩니다.
    sleep(10); // 자식 프로세스들이 setmonopoly를 호출하고 준비될 시간을 보장하기 위해 대기
    monopolize();

    // 두 자식 프로세스가 종료될 때까지 기다림
    wait();
    wait();

    // 자식 프로세스들이 종료된 후, 부모 프로세스의 작업
    for (int i = 0; i < 500; i++)
    {
        int p = getpid();
        printf(1, "PID: %d, ticks: %d\n", p, getticks());
    }

    exit();
}