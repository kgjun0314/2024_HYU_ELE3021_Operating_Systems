#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int i;
    int p;

    p = fork();
    if(p < 0)
    {
        exit();
    }
    else if(p == 0)
    {
        for(i = 0; i < 100; i++)
        {
            printf(1, "Child\n");
            yield();
        }
        exit();
    }
    else
    {
        for(i = 0; i < 100; i++)
        {
            printf(1, "Parent\n");
            yield();
        }
        wait();
        exit();
    }

    exit();
}